WooCommerce Cart Tab
====================

Displays a link to the cart which is visible sitewide and fixed in position so it remains visible wherever the user scrolls. When the user hovers over the tab, the full cart widget is displayed.